from django.http import HttpResponse

def index(request):
    return HttpResponse("Bienvenido al catálogo de la biblioteca local.")
